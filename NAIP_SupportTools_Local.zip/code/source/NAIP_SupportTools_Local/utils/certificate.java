package NAIP_SupportTools_Local.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2015-07-13 15:27:15 EEST
// -----( ON-HOST: fiesnaipisvd11.emea.nsn-net.net

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.text.DateFormat;
import java.util.Date;
// --- <<IS-END-IMPORTS>> ---

public final class certificate

{
	// ---( internal utility methods )---

	final static certificate _instance = new certificate();

	static certificate _newInstance() { return new certificate(); }

	static certificate _cast(Object o) { return (certificate)o; }

	// ---( server methods )---




	public static final void certcheck (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(certcheck)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required path
		// [i] field:0:required password
		// [i] field:0:required checkDays
		// [o] recref:1:required certinfo NAIP_SupportTools_Local.flows.docs:certinfo
		try{
		
			IDataCursor pipelineCursor=pipeline.getCursor();			
			List outputList= new ArrayList();
		
			String keystoreFilename =IDataUtil.getString(pipelineCursor,"path") ;
			char[] passwordArray=IDataUtil.getString(pipelineCursor,"password").toCharArray();
			int checkDays=Integer.parseInt(IDataUtil.getString(pipelineCursor,"checkDays"));
		
			KeyStore keystore = KeyStore.getInstance("JKS");
			File keyStoreFile= new File(keystoreFilename);
		
			//load the file stream of the key store file
		
			FileInputStream is = new FileInputStream(keyStoreFile);
			keystore.load(is, passwordArray);
		
			Enumeration<String> enum1 = keystore.aliases();
		
			for (; enum1.hasMoreElements(); ) {
			String alias = (String)enum1.nextElement();
			Certificate cert = keystore.getCertificate(alias); 
			X509Certificate x509cert = (X509Certificate) cert;
			java.util.Date expires = x509cert.getNotAfter();
			Calendar currentDate = new GregorianCalendar();
			Calendar calExp = new GregorianCalendar();
			calExp.setTime(expires); 
			boolean isGoingToExpire=calExp.after(currentDate);
			long diffMillis = calExp.getTimeInMillis() - currentDate.getTimeInMillis();
			long diffDays = diffMillis / (24 * 60 * 60 * 1000);
			if ( diffDays < checkDays) {
			                   
				IData certinfo=IDataFactory.create();
				IDataCursor certinfoCursor=certinfo.getCursor();
				IDataUtil.put(certinfoCursor, "alias", alias);
				IDataUtil.put(certinfoCursor, "daysLeft", String.valueOf(diffDays));
				IDataUtil.put(certinfoCursor, "serial", String.valueOf(x509cert.getSerialNumber()));
				IDataUtil.put(certinfoCursor, "stillValid", String.valueOf(isGoingToExpire));
				IDataUtil.put(certinfoCursor, "subject", x509cert.getSubjectX500Principal().toString());
				IDataUtil.put(certinfoCursor, "validFrom", x509cert.getNotBefore().toString());
				IDataUtil.put(certinfoCursor, "validTo", x509cert.getNotAfter().toString());
				certinfoCursor.destroy();
				outputList.add(certinfo);
			}
			}
		
			//close the file stream
			is.close(); 
		
			IData[] out1=(IData[])outputList.toArray(new IData[0]);
			IDataUtil.put(pipelineCursor,"certinfo",out1);
			pipelineCursor.destroy();
		
		}catch(Exception e){}
				
				
		
			
		// --- <<IS-END>> ---

                
	}
}

