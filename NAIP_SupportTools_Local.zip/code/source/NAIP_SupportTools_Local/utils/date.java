package NAIP_SupportTools_Local.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2007-01-24 17:25:52 EET
// -----( ON-HOST: saenad20.europe.nokia.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Date;
import java.text.*;
import java.util.TimeZone;
// --- <<IS-END-IMPORTS>> ---

public final class date

{
	// ---( internal utility methods )---

	final static date _instance = new date();

	static date _newInstance() { return new date(); }

	static date _cast(Object o) { return (date)o; }

	// ---( server methods )---




	public static final void addMillis (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(addMillis)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required dateIn
		// [i] field:0:required millis
		// [o] object:0:required dateOut
		// pipeline
		try {
			IDataCursor pipelineCursor = pipeline.getCursor();
			pipelineCursor.first( "dateIn" );
			Date	date = (Date) pipelineCursor.getValue();
			pipelineCursor.first( "millis" );
			long	millis =  Long.decode( (String) pipelineCursor.getValue()).longValue();
			pipelineCursor.destroy();
		
			date.setTime(date.getTime() + millis);
		
			// pipeline
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			pipelineCursor_1.last();
			pipelineCursor_1.insertAfter( "dateOut", date);
			pipelineCursor_1.destroy();
		} catch (Exception e) {
			throw new ServiceException("Error on the inputs: " + e);
		}
		// --- <<IS-END>> ---

                
	}



	public static final void difDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(difDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required startDateTime
		// [i] object:0:required endDateTime
		// [o] field:0:required difDateSec
		// [o] field:0:required difDateMin
		// [o] field:0:required difDateHr
		// [o] field:0:required difDateDay
		// pipeline
		try {
			IDataCursor pipelineCursor = pipeline.getCursor();
			pipelineCursor.first( "startDateTime" );
			Date	startDateTime = (Date) pipelineCursor.getValue();
			pipelineCursor.first( "endDateTime" );
			Date	endDateTime = (Date) pipelineCursor.getValue();
			pipelineCursor.destroy();
		
			double  timediff = endDateTime.getTime() - startDateTime.getTime();
		
			String displayTimeSec = Double.toString(timediff/1000);
			String displayTimeMin = Double.toString(timediff/60000);
			String displayTimeHr = Double.toString(timediff/3600000);
			String displayTimeDay = Double.toString(timediff/86400000);
		
			// pipeline
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			pipelineCursor_1.last();
			pipelineCursor_1.insertAfter( "difDateSec", displayTimeSec);
			pipelineCursor_1.insertAfter( "difDateMin", displayTimeMin);
			pipelineCursor_1.insertAfter( "difDateHr", displayTimeHr);
			pipelineCursor_1.insertAfter( "difDateSecDay", displayTimeDay);
			pipelineCursor_1.destroy();
		} catch (Exception e) {
			throw new ServiceException("Error on input Date objects: " + e);
		}
		// --- <<IS-END>> ---

                
	}
}

