package NAIP_SupportTools_Local.utils;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2007-08-28 15:15:21 EEST
// -----( ON-HOST: saenai20.europe.nokia.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
// --- <<IS-END-IMPORTS>> ---

public final class os

{
	// ---( internal utility methods )---

	final static os _instance = new os();

	static os _newInstance() { return new os(); }

	static os _cast(Object o) { return (os)o; }

	// ---( server methods )---




	public static final void exec (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(exec)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required command
		// [i] object:0:optional initialBufferSize
		// [o] field:0:required output
		// [o] field:0:required returnCode
		String output = "";
		int returnCode = 0;
		
		// Get Input Parameters from Pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String command = IDataUtil.getString( pipelineCursor, "command" );
		int initialBufferSize = IDataUtil.getInt( pipelineCursor, "initialBufferSize", 1024 );
		pipelineCursor.destroy();
		
		// Pre-allocate atleast 1kB
		if (initialBufferSize < 1024)
		{
		   initialBufferSize = 1024;
		}
		
		// Execute The Command
		try {
		  Runtime runtime = Runtime.getRuntime();
		  Process process = runtime.exec(command);
		
		  // Capture The Output of the Command
		  InputStream inputStream = process.getInputStream();
		  InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
		  BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		
		
		  // Iterate of Each Line of Output
		  StringBuffer outputBuffer = new StringBuffer(initialBufferSize);
		  String line = null;
		  while ((line = bufferedReader.readLine()) != null) {
		    // Add line to output 
		    outputBuffer.append(line + '\n');
		  }
		  output = outputBuffer.toString();
		
		
		  // Check for Command Failure
		  try {
		    if (process.waitFor() != 0) {
		      returnCode = process.exitValue();
		    }
		  } catch (InterruptedException e) {
		    output += e.toString();
		 	
		  }  
		
		} catch (IOException ioe) {
		  output += ioe.toString();
		}
		
		
		// Place Command Output and Return Code in Output Pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put(pipelineCursor_1, "returnCode", Integer.toString(returnCode));
		IDataUtil.put(pipelineCursor_1, "output", output);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

